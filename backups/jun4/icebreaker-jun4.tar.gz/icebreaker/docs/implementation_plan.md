# AI-Native OS — Engineering Implementation Plan

**Reference:** [`AI_Native_OS_Whitepaper.md`](../AI_Native_OS_Whitepaper.md)  
**Status:** Living document — update when phase gates pass or decisions change  
**Last updated:** May 2026

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Critical Path & Build Order](#2-critical-path--build-order)
3. [Phase-by-Phase Breakdown](#3-phase-by-phase-breakdown)
4. [Failure Mode Register](#4-failure-mode-register)
5. [Risk Mitigation Through Implementation Choices](#5-risk-mitigation-through-implementation-choices)
6. [Testing Strategy](#6-testing-strategy)
7. [Go / No-Go Gate Checklist](#7-go--no-go-gate-checklist)

---

## 1. Project Overview

The AI-Native OS is a fork of Ubuntu Linux in which a locally-running LLM is a first-class citizen of the operating system — not an application on top of it. Users express intent in natural language; the AI translates it into safe, auditable system operations executed directly against the Linux kernel.

The architecture has five load-bearing components:

| Component | Language | What It Does |
|---|---|---|
| **Quarantined Brain** | Runtime (llama.cpp) | NL understanding, intent formulation — zero system access |
| **Privileged Brain** | Runtime (llama.cpp, fine-tuned) | NL→shell execution — zero external data access |
| **Central Controller** | Python / Rust | Schema validation, risk classification, audit logging, HITL gate |
| **mcpd** | Rust | MCP daemon exposing system tools via JSON-RPC over stdio |
| **ISO build** | Shell / live-build | Bootable distribution with models + daemons embedded |

This document defines the exact sequence in which these must be built, why that order is non-negotiable, and every meaningful way the project can fail along the way.

---

## 2. Critical Path & Build Order

### Dependency Graph

```
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 0: Environment + Model Verification                           │
│  (Both GGUF models load, llama.cpp server responds, MCP handshake)  │
└──────────┬───────────────────────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 1: mcpd (Rust MCP Daemon)                                     │
│  EXIT CRITERION: All tool modules pass unit tests,                   │
│  JSON Schema catalogue published, MCP discovery works               │
└──────────┬───────────────────────────────────────────────────────────┘
           │
           ├──────────────────────────────────────────────────────┐
           │                                                      │
           ▼                                                      ▼
┌──────────────────────────┐                  ┌──────────────────────────────┐
│  Phase 2: Dual-Brain     │                  │  Phase 4: Fine-Tune          │
│  Controller              │                  │  Privileged Brain            │
│  (Schema validation,     │                  │  (SFT → DPO → GGUF)         │
│  intent routing, audit)  │                  │  INDEPENDENT TRACK —         │
└──────────┬───────────────┘                  │  runs in parallel with P2/P3 │
           │                                  └──────────────────┬───────────┘
           ▼                                                     │
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 3: Kernel Sandboxing                                          │
│  (Landlock + Seccomp-BPF + COW overlay)                              │
│  EXIT CRITERION: Zero sandbox escapes, <10ms overhead               │
└──────────┬───────────────────────────────────────────────────────────┘
           │ ◄──────────────────────────────────────────────────────────┘
           │ (Phase 4 fine-tuned model plugged in here)
           ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 5: UX Layer + Graduated Determinism                           │
│  (Tier 0–3 risk classifier, HITL prompt, audit log viewer)          │
│  REQUIRES: COW dry-runs (Phase 3) + model quality (Phase 4)         │
└──────────┬───────────────────────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 6: ISO Distribution Engineering                               │
│  (live-build, systemd units, squashfs, QEMU + bare-metal testing)   │
│  REQUIRES: All components stable — never attempt before Phase 5     │
└──────────┬───────────────────────────────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────────────────────────────┐
│  Phase 7: Hardening, Pentest, Release                                │
│  (E2E integration tests, red-team, docs, v1.0 cut)                  │
└──────────────────────────────────────────────────────────────────────┘
```

### Why This Order Is Non-Negotiable

| Constraint | Reason |
|---|---|
| Phase 0 before everything | Without verified model loading and MCP handshake, all subsequent phases are building on unproven assumptions |
| Phase 1 (mcpd) before Phase 2 (Controller) | The Controller validates intent objects against real tool schemas — those schemas come from mcpd's tool catalogue. You cannot write validation logic for tools that don't exist yet |
| Phase 1 before Phase 4 (fine-tuning) | Synthetic training data for the Privileged Brain includes MCP tool call examples. Those examples must use the real, finalised mcpd tool schemas or the model will be trained on wrong formats |
| Phase 3 (sandboxing) before Phase 5 (UX) | The HITL prompt displays COW dry-run output. The risk classifier uses sandbox execution to determine consequences. Without sandboxing, the UX layer is a facade |
| Phase 4 before Phase 5 | The UX layer's value depends on model output quality. Showing users dry-run consequences of hallucinatory commands is actively dangerous |
| Phase 5 before Phase 6 (ISO) | Never bake an unstable system into a bootable image. Debug inside a running OS; distribute only when all exit criteria pass |
| Phase 7 always last | Penetration testing on an incomplete system gives false assurance — attackers will test the complete system |

---

## 3. Phase-by-Phase Breakdown

---

### Phase 0 — Foundation & Environment Setup
**Duration:** Week 1  
**Owned by:** All engineers (setup sprint)

#### Inputs Required
- Fresh Ubuntu 22.04 LTS VM accessible to all developers
- Network access to Hugging Face, PyPI, crates.io, GitHub

#### Tasks

**Environment:**
- [ ] Create monorepo on GitHub with branch protection (require 1 approval + CI pass to merge to `main`)
- [ ] Install: `llama.cpp`, Rust toolchain (stable + nightly), Python 3.11+, `live-build`, `debootstrap`
- [ ] Pin all tool versions in `.tool-versions` (asdf) or `Dockerfile.dev`
- [ ] Configure shared `.env.example` with all required environment variables documented

**Model verification:**
- [ ] Download Phi-4-mini GGUF (Q4_K_M) — record SHA-256 in `models/checksums.sha256`
- [ ] Download Qwen 2.5 Coder 1.5B GGUF (Q4_K_M) — record SHA-256 in `models/checksums.sha256`
- [ ] Start `llama-server` for both models; verify each responds to a `/v1/chat/completions` request
- [ ] Establish a basic MCP stdio connection between `llama-server` and a stub `mcpd` that advertises one dummy tool
- [ ] Document exact working invocation commands in `docs/QUICKSTART.md`

#### Points of Failure
- **P0-F1:** GGUF download is corrupted or truncated → checksum must be verified before any further setup
- **P0-F2:** MPS/CUDA not detected → training will fall back to CPU; document this clearly so engineers don't discover it 6 hours into a training run
- **P0-F3:** llama.cpp API version mismatch with client code → pin llama.cpp commit hash, not just `latest`

#### Exit Criteria
- Both GGUF models load and generate coherent output
- A dummy MCP tool call flows end-to-end through the stdio pipe
- All developers can reproduce the environment from the documented instructions in <30 minutes

---

### Phase 1 — Build the MCP Daemon (mcpd)
**Duration:** Weeks 2–4  
**Owned by:** Rust engineer(s)

#### Inputs Required
- Verified llama.cpp environment (Phase 0 exit)
- Ubuntu 22.04 system for D-Bus testing

#### Tasks

**Scaffold:**
- [ ] `cargo new mcpd --bin` in `src/mcpd/`
- [ ] Add dependencies: `tokio`, `serde`, `serde_json`, `zbus`, `seccompiler`, `landlock`
- [ ] Implement `server.rs` — JSON-RPC 2.0 router over **stdio exclusively** (no TCP socket, no UNIX socket listener)

**Tool modules (implement in this order — each unlocks testing for the next):**
1. `src/tools/system.rs` — read-only stats (uptime, CPU, memory, disk) — safest to build first, easy to test
2. `src/tools/process.rs` — list, inspect — still read-only
3. `src/tools/service.rs` — systemd control via D-Bus (first write-capable module; establish the D-Bus pattern here)
4. `src/tools/fs.rs` — read, write, list, stat, permissions — **all paths validated against a whitelist before execution**
5. `src/tools/network.rs` — interface status, firewall, DNS
6. `src/tools/package.rs` — apt query, install, remove, upgrade — never run without COW dry-run

**Schema publication:**
- [ ] For every tool, write a JSON Schema document in `mcpd/schemas/` — this is the contract the Controller validates against
- [ ] Implement `tools/list` MCP endpoint that returns the full schema catalogue at runtime
- [ ] Version the schema catalogue (`mcpd/schemas/schema-version.json`) — Controller must reject connections from mismatched versions

**D-Bus proxy:**
- [ ] Implement `dbus/system_bus.rs` and `dbus/session_bus.rs` with lazy connection — gracefully degrade if SessionBus is absent (headless server context)

**Tests:**
- [ ] Unit test for every tool module — mock D-Bus calls; test path validation exhaustively
- [ ] Integration test: start mcpd, run MCP discovery, invoke each tool, verify output

#### Points of Failure
- **P1-F1: TCP listener accidentally added** — any network listener in mcpd is a remote attack surface. The CI pipeline must assert `ss -tlnp` shows zero mcpd listeners.
- **P1-F2: Path traversal in fs.rs** — `fs.read("../../etc/shadow")` must be caught by validation. Add fuzzing tests with path traversal payloads on day one.
- **P1-F3: D-Bus session bus absent on server** — lazy initialization prevents crashes; test this explicitly by running mcpd in a headless environment with `DBUS_SESSION_BUS_ADDRESS` unset.
- **P1-F4: Schema drift** — if a tool's behavior changes but its schema is not updated, the Controller will accept calls that the tool rejects at runtime. Schema version enforcement prevents silent mismatches.

#### Exit Criteria
- All tool modules pass unit tests
- MCP tool discovery returns the full schema catalogue
- `ss -tlnp` shows no mcpd network listeners
- fs.rs rejects 100% of path traversal inputs in fuzz test
- D-Bus absent → affected tools report `unavailable`, mcpd stays running

---

### Phase 2 — Dual-Brain Controller
**Duration:** Weeks 5–7  
**Owned by:** Backend engineer(s)

#### Inputs Required
- mcpd schema catalogue (Phase 1 exit)
- Both GGUF models running (Phase 0)

#### Tasks

**Intent Object schema:**
- [ ] Define the canonical Intent Object JSON Schema in `controller/schemas/intent.json`
- [ ] Fields: `action` (string, enum from mcpd catalogue), `target` (string), `params` (object, validated against mcpd tool schema), `reason` (enum: user_requested | ai_autonomous | scheduled), `risk_level` (enum: read_only | low | medium | high | critical)
- [ ] Add negative test suite: malformed intents, extra fields, injection attempts in string fields — all must be rejected

**Controller process:**
- [ ] Schema validation — reject any field outside the defined schema; never pass through unexpected fields
- [ ] Reference variable store — `intent_store.rs` (or `.py`): maps `UUID → validated intent object`; opaque IDs passed to Privileged Brain
- [ ] Risk classifier v1: rule-based classification of `risk_level` from action + target
- [ ] Audit logger: append-only structured log (JSON Lines) with timestamp, intent ID, risk level, user, outcome
- [ ] HITL gate: blocking prompt at `risk_level = high | critical`; non-blocking notification at `medium`

**Brain configuration:**
- [ ] Quarantined Brain system prompt: defines role, explicitly lists tools it is NOT connected to, instructs it to produce Intent Objects via a specific output format
- [ ] Privileged Brain system prompt: defines role, explicitly states it only receives opaque reference IDs, never raw user content
- [ ] Wire both models to Controller (Quarantined Brain → Controller input; Controller → Privileged Brain via opaque ID)

**Adversarial testing:**
- [ ] Craft 20 prompt injection payloads (embedded in fake document text, email bodies, web page content)
- [ ] Feed each to Quarantined Brain; verify no system command executes
- [ ] Verify intent objects produced from injected input are rejected at Controller schema validation

#### Points of Failure
- **P2-F1: Raw text leaks into Privileged Brain** — this is the central security invariant. The opaque reference ID store must be tested to confirm the Privileged Brain receives IDs, not text content.
- **P2-F2: Schema validation has edge-case bypass** — test string fields with SQL/shell injection characters (`; rm -rf /`, `' OR '1'='1`). The schema must reject these via format/pattern validators, not ad-hoc string checks.
- **P2-F3: Audit log is not append-only** — if the audit log can be modified or deleted, an attacker can erase the record of a compromise. Use `O_APPEND` file mode; consider a write-ahead log or syslog forwarding.
- **P2-F4: Both brains wired to the same MCP connection** — the Quarantined Brain must have zero mcpd connection. Verify this at startup: the Quarantined Brain's MCP client list must be empty.

#### Exit Criteria
- 20/20 prompt injection payloads produce no system command execution
- Controller rejects 100% of malformed/extra-field intent objects
- Quarantined Brain MCP tool list is empty at runtime
- Privileged Brain receives only opaque IDs, never raw user text (verified by log inspection)
- Audit log entries are written for every intent, including rejected ones

---

### Phase 3 — Kernel-Level Sandboxing
**Duration:** Weeks 8–10  
**Owned by:** Systems engineer(s)

#### Inputs Required
- mcpd running with tool modules (Phase 1)
- Controller wiring complete (Phase 2)
- Kernel ≥ 5.13 (Landlock), ≥ 3.5 (Seccomp-BPF) — verify with `uname -r`

#### Tasks

**Landlock:**
- [ ] Check kernel version at mcpd startup; log and exit cleanly if Landlock is unavailable
- [ ] Define Landlock rulesets per tool domain (minimum necessary filesystem access):
  - `system.*` and `process.*`: read `/proc`, `/sys` only
  - `service.*`: `/etc/systemd/`, D-Bus socket only
  - `fs.*`: configurable per-operation whitelist, derived from validated target path
  - `network.*`: `/etc/resolv.conf`, `/etc/hosts`, netlink socket
  - `package.*`: `/var/lib/apt/`, `/var/cache/apt/`, `/etc/apt/`
- [ ] Apply ruleset before spawning any execution child process — not after
- [ ] Verify: attempt to `open("/boot/vmlinuz")` from within sandbox → EACCES

**Seccomp-BPF:**
- [ ] Define syscall whitelist for execution child processes
- [ ] Compile BPF filter using `seccompiler` crate
- [ ] Install filter in child process before `execve`
- [ ] Verify: attempt a blocked syscall → SIGKILL

**COW overlay:**
- [ ] Implement `cow/overlay.rs`: mounts `tmpfs` over affected path before any `fs.write` or `fs.delete` outside home dir
- [ ] Implement `cow/analysis.rs`: captures file change diff (paths, sizes, permissions) from the overlay
- [ ] Implement `cow/report.rs`: generates human-readable dry-run report (what will change, how much space freed/used)
- [ ] Implement `cow/commit.rs` and `cow/rollback.rs`: atomically apply or discard overlay changes
- [ ] Integrate with Controller: Controller calls `cow.dry_run()` before any Tier 2+ operation; surfaces report to user

**Benchmarking:**
- [ ] Measure latency of each security layer in isolation (goal: each layer <1ms)
- [ ] Measure end-to-end latency with all layers active (goal: <10ms total overhead)
- [ ] Record baseline numbers in `docs/BENCHMARKS.md`

**Red-team self-audit:**
- [ ] Attempt known Linux sandbox escape techniques against the running sandbox
- [ ] Attempt to read `/etc/shadow` from within the sandbox
- [ ] Attempt to spawn a network socket from the execution child

#### Points of Failure
- **P3-F1: Landlock not available on target kernel** — runtime check + hard exit prevents silent security degradation.
- **P3-F2: Ruleset applied after execve** — Landlock must be applied in the parent process before forking the execution child. If applied in the child after fork, there is a race window.
- **P3-F3: COW commit is not atomic** — a crash during commit leaves partial changes on disk. Use rename-on-commit semantics; write to temp path then rename to final path.
- **P3-F4: tmpfs for COW is on the wrong mount namespace** — if the overlay mounts don't share the same mount namespace as the execution child, changes are invisible to the analysis step.
- **P3-F5: Seccomp whitelist is too permissive** — start from a deny-all policy and add only what's needed. Never start from allow-all and remove.

#### Exit Criteria
- Zero successful reads of filesystem paths outside Landlock ruleset
- Zero successful blocked syscalls (SIGKILL fires correctly)
- COW dry-run captures all file changes with <5ms overhead
- COW commit is atomic (verified by crash-injection test)
- Total security layer overhead: <10ms on reference hardware

---

### Phase 4 — Fine-Tuning the Privileged Brain
**Duration:** Weeks 11–15 (parallel track — can run alongside Phase 2/3)  
**Owned by:** ML engineer(s)  
**Existing scaffolding:** `privileged-brain/` directory with training scripts

#### Inputs Required
- mcpd tool schemas finalized (Phase 1 exit) — synthetic data generation depends on them
- GPU access: RTX 3080/4070 or cloud GPU (A10G/L4) with ≥8GB VRAM

#### Tasks

**Data pipeline:**
- [ ] Run `02_get_data.sh` — downloads NL2Bash + bash-commands-dataset
- [ ] Run `scripts/process_datasets.py` — formats into train/valid split (`.jsonl`)
- [ ] Run `03_generate_synthetic.sh` (requires `ANTHROPIC_API_KEY`) — target 50,000 pairs across all categories including adversarial refusals
- [ ] **Data validation pass** (critical — see P4-F1):
  - Run a classifier on all `bash` fields to detect commands touching `/boot`, `/root`, `sudoers`, kernel modules
  - Any such command in a non-refusal example must be manually reviewed before training
  - Human spot-check 5% of synthetic pairs for quality
- [ ] Generate DPO preference pairs via `scripts/generate_dpo_pairs.py` — 1,000+ (safe, preferred) vs (dangerous, rejected) pairs

**Training:**
- [ ] Run `04_train.sh` — SFT 3 epochs, then DPO 2 epochs
- [ ] Monitor loss curve: SFT target ~2.0 start → ~0.4 after epoch 3
- [ ] If SFT loss stuck > 1.5 after 500 steps: re-run with `--low-memory --lr 1e-4`
- [ ] Save checkpoints every 500 steps; verify checkpoint integrity before proceeding to DPO

**Post-training:**
- [ ] Run `05_convert_and_import.sh` — fuse LoRA adapter, quantize to GGUF Q4_K_M
- [ ] **Hash verification**: record SHA-256 of the final GGUF in `models/checksums.sha256`
- [ ] Load fine-tuned model into llama.cpp with GBNF grammar (`inference/grammar/mcp_tool_call.gbnf`)
- [ ] Verify grammar: generate outputs for 1,000 known-good prompts; assert 100% parse as valid JSON MCP calls

**Evaluation:**
- [ ] Run `07_evaluate.sh` — FEH evaluation vs baseline
- [ ] Target: >90% Functional Equivalence Score on held-out test set
- [ ] Target: 100% structural validity (zero invalid MCP output)
- [ ] Compare fine-tuned vs base model on adversarial refusal prompts — fine-tuned must refuse ≥95%

#### Points of Failure
- **P4-F1: Training data contamination** — dangerous commands in non-refusal examples teach the model to execute them. The validation pass is not optional.
- **P4-F2: Base model / LoRA version mismatch** — DPO adapter built from SFT adapter; if SFT used a different base model hash than DPO, the fused weights are corrupted. Pin `model_id` and assert the same base in `fuse_lora.py`.
- **P4-F3: OOM crash with no checkpoint** — `save_steps=500` in `sft_train.py` mitigates this. Before the overnight run, verify the checkpoint directory exists and is writable.
- **P4-F4: Over-constrained grammar stalls inference** — test `mcp_tool_call.gbnf` against 1,000 known-good outputs before deployment. If any valid call fails to generate, the grammar needs widening.
- **P4-F5: FEH evaluation environment differs from production** — the COW sandbox used for FEH evaluation must match the production sandbox configuration. Run evaluation inside the sandbox.

#### Exit Criteria
- Fine-tuned model achieves >90% FEH score on held-out test set
- 100% of generated outputs are valid JSON MCP calls (grammar-constrained)
- Fine-tuned model refuses ≥95% of adversarial refusal prompts
- Final GGUF fits in <2.5GB RAM at runtime
- SHA-256 of final GGUF recorded in `models/checksums.sha256`

---

### Phase 5 — UX Layer & Graduated Determinism
**Duration:** Weeks 16–18  
**Owned by:** Frontend / UX engineer(s) + Controller engineer

#### Inputs Required
- COW overlay system complete (Phase 3)
- Fine-tuned model available (Phase 4)
- Controller wiring complete (Phase 2)

#### Tasks

**Risk classifier (Tier 0–3):**
- [ ] Tier 0: hardcoded list of all read-only MCP tools (`system.status`, `fs.read`, `process.list`, `service.logs`, `network.status`) — always auto-execute, never prompt
- [ ] Tier 1: rule-based classifier — writes to user home dir, user service restarts — auto-execute with audit log
- [ ] Tier 2: lightweight LLM pass — scope check, injection pattern detection, consequence analysis — auto-execute with notification if approved
- [ ] Tier 3: blocking HITL prompt — any `fs.delete`, `fs.write` outside home dir, firewall changes, kernel params, any path under `/boot`, `/etc/sudoers`, `/root`
- [ ] **Add monitoring**: log `risk_level` for every operation; instrument for approval latency tracking

**HITL prompt UI:**
- [ ] Display: intent in plain English, exact MCP tool call + params, COW dry-run report, risk assessment, reversibility
- [ ] Actions: `[A]pprove`, `[D]eny`, `[E]xplain more`, `[M]odify command`
- [ ] Timer: if no response in 30 seconds, escalate (don't auto-approve)
- [ ] Approval latency logging: track time-to-approve; if median < 2 seconds, risk thresholds need recalibration

**Audit log viewer:**
- [ ] CLI: `ainative audit list [--since] [--risk-level] [--outcome]`
- [ ] Display: timestamp, intent, command, dry-run summary, user decision, outcome

**Usability testing:**
- [ ] Simulate 1 week of common sysadmin tasks in natural language
- [ ] Count Tier 3 prompts triggered (target: <5/day)
- [ ] Count rubber-stamped approvals (< 2s latency) — if >10%, recalibrate tier thresholds

#### Points of Failure
- **P5-F1: Approval fatigue** — Tier 3 triggered too often makes security theatre. Measure and recalibrate.
- **P5-F2: HITL prompt approved before dry-run is shown** — the UI must block the approve option until the dry-run report is displayed and at least 3 seconds have elapsed.
- **P5-F3: Tier classifier has hardcoded paths instead of schema-driven rules** — as mcpd tool schemas evolve, new tools must inherit correct tier automatically. Classify by tool capability flags in the schema, not by hardcoded tool name strings.

#### Exit Criteria
- Tier 3 prompts: <5 per day in simulated normal usage
- Zero Tier 3 prompts approved in <3 seconds in usability testing
- Audit log correctly records every operation with correct outcome
- Users complete 10 common sysadmin tasks in natural language with zero prior training

---

### Phase 6 — Distribution Engineering (The ISO)
**Duration:** Weeks 19–22  
**Owned by:** DevOps / release engineer

#### Inputs Required
- All Phase 0–5 components stable and passing exit criteria
- Final GGUF model files with verified SHA-256 checksums
- All Rust binaries compiled for target architecture

#### Tasks

**live-build setup:**
- [ ] Create `cx-distro/` directory structure (see whitepaper Section 9)
- [ ] Write `build.sh` — **must verify SHA-256 of all GGUF files before mksquashfs; fail hard on mismatch**
- [ ] Write `preseed.cfg` — unattended installation; zero manual steps
- [ ] Write systemd unit files: `mcpd.service`, `privileged-brain.service`, `quarantined-brain.service`
  - Define `After=` and `Requires=` dependencies: brains cannot start until mcpd is ready
  - `mcpd.service`: `Type=notify`, `NotifyAccess=main` — systemd waits for daemon-ready signal
- [ ] Write `config.toml` — system-wide AI configuration (model paths, risk tier thresholds, audit log path)

**Build pipeline:**
- [ ] Pin all apt package versions in `cx-core.list.chroot`
- [ ] Pin `debootstrap` to specific suite snapshot
- [ ] Containerize the build process (Docker container for the BUILD, not for production)
- [ ] Publish build logs and checksums alongside every ISO

**Testing:**
- [ ] Boot ISO in QEMU: `qemu-system-x86_64 -m 8G -boot d -cdrom ainative.iso`
- [ ] Verify boot-to-AI-ready time < 60 seconds
- [ ] Bare-metal boot test on three different hardware configurations
- [ ] Fresh install test on each hardware configuration
- [ ] Run the full adversarial test suite inside the ISO environment

#### Points of Failure
- **P6-F1: Wrong model weights embedded** — `build.sh` must verify SHA-256 from `models/checksums.sha256` before embedding. This check is mandatory, not optional.
- **P6-F2: systemd ordering race** — if Privileged Brain starts before mcpd is ready, the first tool call fails silently. Use `Type=notify` + `sd_notify()` in mcpd to signal readiness.
- **P6-F3: Non-reproducible build** — pinned package versions + containerized build environment + SHA-256 manifest must all be in place before first public release.
- **P6-F4: ISo tested only in QEMU, not bare metal** — QEMU masks many real hardware compatibility issues. Test on physical hardware before claiming the exit criteria are met.

#### Exit Criteria
- ISO boots cleanly on bare metal (3 hardware configurations)
- Boot-to-AI-ready: < 60 seconds from power-on
- Installation requires zero manual steps
- `build.sh` SHA-256 check passes for all embedded model files
- Full adversarial test suite passes inside the ISO environment

---

### Phase 7 — Hardening, Pentest & Release
**Duration:** Weeks 23–26  
**Owned by:** All engineers + external security review

#### Tasks
- [ ] End-to-end integration test: run the complete pipeline (user input → Quarantined Brain → Controller → Privileged Brain → mcpd → kernel → user output) with 500 representative queries
- [ ] Penetration test: attempt prompt injection, sandbox escape, privilege escalation using latest known Linux kernel techniques
- [ ] Performance profiling: identify and resolve any p95 latency >500ms
- [ ] Documentation: user guide, developer API reference, security architecture overview, responsible disclosure policy
- [ ] Cut v1.0 release; publish ISO with GPG signature and SHA-256 manifest

#### Exit Criteria
- Zero confirmed sandbox escapes in penetration test
- p95 latency <500ms for Tier 0/1 operations (500-query benchmark)
- ISO published with GPG signature
- All documentation complete

---

## 4. Failure Mode Register

Each failure mode is categorized by **Severity** (CRITICAL / HIGH / MEDIUM / LOW), **Likelihood** (High / Medium / Low), and includes detection and recovery strategies.

> Failure modes F1–F8 are defined in the whitepaper Section 12. F9–F15 are additional modes identified during implementation planning.

---

### F1 — Prompt Injection Breaks Security Boundary
**Severity:** CRITICAL | **Likelihood:** High (this is an active attack vector)  
**Description:** Malicious document/email content causes Quarantined Brain to formulate dangerous intents that flow through Controller to execution.  
**Detection:** Adversarial test suite (1,000 injection prompts) run weekly; any execution resulting from external data triggers an alert.  
**Mitigation:**
- Controller validates strict schema; unexpected fields → reject entire intent
- Intent objects never carry raw text — only action/target/param tuples
- Adversarial fine-tuning teaches Quarantined Brain to neutralize injections  
**Recovery:** Kill the active session; audit log review to determine what executed; patch schema validation to close the bypass.

---

### F2 — Latency Exceeds 100ms
**Severity:** HIGH | **Likelihood:** Medium  
**Description:** Combined pipeline latency makes the AI slower than raw Bash; users abandon it.  
**Detection:** Automated benchmark (500 queries) measuring p50/p95/p99 at end of each phase gate.  
**Mitigation:**
- Speculative decoding implemented from Phase 0 (not retrofit)
- Landlock/Seccomp benchmarked in isolation (each must be <1ms)
- Never use Docker/VMs for production sandboxing
- Both models resident in memory at all times — no cold-start loading  
**Recovery:** Profile the pipeline with `perf`/`flamegraph`; identify the dominant latency source; resolve before proceeding.

---

### F3 — Fine-Tuned Model Hallucinates Dangerous Commands
**Severity:** HIGH | **Likelihood:** Medium  
**Description:** Privileged Brain generates a structurally valid but semantically dangerous command.  
**Detection:** FEH evaluation weekly; COW dry-run catches unexpected filesystem consequences before commit.  
**Mitigation:**
- Grammar-constrained decoding (GBNF) prevents structurally invalid outputs
- COW dry-run exposes all filesystem consequences before commit
- Adversarial DPO training teaches preference for reversible, minimal-scope commands
- Tier 3 HITL gate on all critical-path operations  
**Recovery:** Roll back to previous model checkpoint; add the failure case to DPO preference pairs; retrain.

---

### F4 — Approval Fatigue Neutralizes Security
**Severity:** MEDIUM-HIGH | **Likelihood:** High (this is a known UX failure mode in security systems)  
**Description:** Users rubber-stamp Tier 3 prompts without reading them.  
**Detection:** Monitor approval latency; alert if median < 2 seconds.  
**Mitigation:**
- Tier 3 prompts must be rare (<5/day in normal usage)
- HITL prompt shows dry-run consequences, not just "are you sure?"
- Approve button disabled for first 3 seconds  
**Recovery:** Recalibrate tier thresholds to move more operations to Tier 1/2; improve dry-run report clarity.

---

### F5 — mcpd Becomes Root Execution Backdoor
**Severity:** CRITICAL | **Likelihood:** Low (Rust memory safety + stdio isolation)  
**Description:** Vulnerability in mcpd allows arbitrary command execution beyond the tool surface.  
**Detection:** Penetration testing; CI fuzzing of all tool parameter inputs.  
**Mitigation:**
- stdio-only communication — no network listener
- All parameters validated against JSON Schema before execution
- Rust memory safety eliminates buffer overflow / use-after-free classes
- Landlock and Seccomp confine mcpd's own execution context  
**Recovery:** Pull the mcpd binary from the running system; hotfix the vulnerability; re-deploy.

---

### F6 — ISO Build Is Not Reproducible
**Severity:** MEDIUM | **Likelihood:** Medium  
**Description:** Different builds produce different ISOs; users cannot verify what they're running.  
**Detection:** Build two ISOs from the same commit on different machines; diff the SHA-256 checksums.  
**Mitigation:**
- Pin all package versions in apt list
- Containerized build environment
- SHA-256 manifest for all embedded binaries  
**Recovery:** Investigate non-deterministic build step; pin any unpinned versions; rebuild.

---

### F7 — Model Weights Compromised in ISO
**Severity:** MEDIUM | **Likelihood:** Low  
**Description:** Forked ISO ships malicious model weights that behave differently from published weights.  
**Detection:** Compare ISO model weight SHA-256 against published Hugging Face checksums.  
**Mitigation:**
- ISO signed with GPG key
- SHA-256 of all model weights published alongside ISO
- mcpd verifies weight checksums at startup; refuses to load unverified models  
**Recovery:** Yank the compromised ISO; publish signed replacement; notify users via responsible disclosure.

---

### F8 — Coordinated AI Agent Work Introduces Subtle Bugs
**Severity:** MEDIUM | **Likelihood:** High (especially relevant for this project)  
**Description:** Coding agents make conflicting changes, violate module boundaries, or introduce bugs that pass tests but violate architectural invariants.  
**Detection:** Human code review on every PR; architecture invariant tests in CI.  
**Mitigation:**
- Agents work in isolated branches; merge only after human review
- Narrow task scope per agent — never ask an agent to implement a full phase
- `CLAUDE.md` encodes architectural invariants that agents must reference
- One human engineer owns each module and reviews all agent changes to it  
**Recovery:** Revert the offending commit; fix manually; add a regression test for the violated invariant.

---

### F9 — Training Data Contamination *(new)*
**Severity:** HIGH | **Likelihood:** Medium  
**Description:** Dangerous or incorrect commands slip into training data through synthetic generation, teaching the model to emit them.  
**Detection:** Automated classifier on all `bash` fields; human spot-check of 5% of synthetic pairs.  
**Mitigation:**
- Classifier rejects any `bash` field touching `/boot`, `/root`, `/etc/sudoers`, kernel modules — unless the example is an adversarial refusal
- All generated data reviewed before training starts
- Keep a clean held-out validation set from the original curated datasets (not synthetic)  
**Recovery:** Remove contaminated examples; retrain from last clean checkpoint.

---

### F10 — LoRA Adapter / Base Model Version Mismatch *(new)*
**Severity:** HIGH | **Likelihood:** Medium  
**Description:** SFT and DPO adapters are trained from different base model versions; fused weights are silently corrupt.  
**Detection:** Assert base model SHA-256 matches between SFT and DPO training configs; verify in `fuse_lora.py` at load time.  
**Mitigation:**
- Pin exact base model ID and hash in both `sft_train.py` and `dpo_train.py`
- `fuse_lora.py` asserts the base model used matches a stored hash before merging  
**Recovery:** Re-run DPO training from the correct SFT checkpoint base.

---

### F11 — OOM Crash Kills Training Mid-Run *(new)*
**Severity:** MEDIUM | **Likelihood:** Medium (especially on MPS with large batches)  
**Description:** 6-hour SFT run dies at hour 5 with no usable checkpoint; all progress lost.  
**Detection:** Monitor training log; alert on process exit without clean completion.  
**Mitigation:**
- `save_steps=500` in `sft_train.py` (every ~30 minutes at typical throughput)
- `--resume` flag in `04_train.sh` restarts from latest checkpoint
- Before the overnight run: verify checkpoint directory exists and is writable, and run one test step  
**Recovery:** Resume from the latest checkpoint; if checkpoints are corrupt, drop to `--low-memory` mode and restart.

---

### F12 — Grammar FSM Rejects Valid Outputs (Over-Constrained) *(new)*
**Severity:** MEDIUM | **Likelihood:** Low  
**Description:** GBNF grammar is too strict; llama.cpp stalls or produces empty output for valid tool calls.  
**Detection:** Test grammar against 1,000 known-good MCP tool call examples before deployment.  
**Mitigation:**
- Grammar is versioned alongside mcpd tool schemas in `inference/grammar/`
- Regression test: new tool added to mcpd must update grammar + pass grammar validation test  
**Recovery:** Widen the grammar; regenerate FSM; re-test.

---

### F13 — Landlock Kernel Version Incompatibility *(new)*
**Severity:** HIGH | **Likelihood:** Low (Ubuntu 22.04 ships kernel 5.15+, but older HW may run older kernels)  
**Description:** ISO runs on kernel < 5.13 where Landlock is unavailable; security silently degrades.  
**Detection:** mcpd checks kernel version at startup.  
**Mitigation:**
- Hard minimum: kernel 5.15 (Ubuntu 22.04 LTS baseline)
- mcpd startup: `uname -r` check; if below minimum, print clear error and exit — never run without Landlock  
**Recovery:** Boot with a compatible kernel; the ISO enforces 5.15+.

---

### F14 — D-Bus SessionBus Absent on Server *(new)*
**Severity:** LOW | **Likelihood:** High (headless server installs never have a SessionBus)  
**Description:** mcpd initializes session-bus tools at startup, crashes when `DBUS_SESSION_BUS_ADDRESS` is unset.  
**Detection:** Run mcpd in headless container with no SessionBus; verify it starts cleanly.  
**Mitigation:**
- Session-bus connection is lazy-initialized per tool call, not at daemon startup
- Tool discovery marks session-bus tools as `available: false` when bus is absent
- mcpd logs a single warning and continues; does not exit  
**Recovery:** This is handled gracefully; no recovery action needed.

---

### F15 — ISO Embeds Wrong Model Weights *(new)*
**Severity:** HIGH | **Likelihood:** Medium (build scripts are complex; human error is plausible)  
**Description:** `build.sh` copies stale GGUF files from a development directory; users run an un-fine-tuned base model.  
**Detection:** `build.sh` computes SHA-256 of each GGUF before embedding and compares against `models/checksums.sha256`.  
**Mitigation:**
- Build fails hard (`set -e; exit 1`) if any checksum mismatches
- The SHA-256 manifest is committed alongside the model training run output
- mcpd verifies model checksums at daemon startup (defense in depth)  
**Recovery:** Fix the build script; rebuild the ISO with correct weights; re-publish with updated checksums.

---

## 5. Risk Mitigation Through Implementation Choices

This section documents *why* each major architectural decision was made — and what risk it directly mitigates. Every design choice was made to eliminate a specific failure mode, not for aesthetic reasons.

### Dual-Brain Architecture → Mitigates F1 (Prompt Injection)

A single LLM with both perception and execution capability is a confounded deputy attack waiting to happen. Separating into two isolated models with a strict communication channel means a compromised Quarantined Brain has nothing to act on — it has no execution tools. The Privileged Brain, which has root, is blind to all external data. This is the most important architectural decision in the project.

### Grammar-Constrained Decoding (GBNF) → Mitigates F3 (Hallucination)

An LLM can output structurally invalid JSON or malformed bash pipelines even when it "knows better." Grammar-constrained decoding makes it mathematically impossible to generate invalid output — the logit probabilities of non-conforming tokens are set to negative infinity. Zero hallucinated JSON. Zero broken tool calls. This is a hard technical guarantee, not a probabilistic one.

### COW Overlay Dry-Runs → Mitigates F3 and F4

Even a correct command can have unexpected consequences in a specific system state. The COW overlay system executes the command in a copy-on-write sandbox, captures all filesystem changes, and shows them to the user *before* committing. This transforms the HITL prompt from a blind "are you sure?" into an informed consent decision: the user sees exactly what will change.

### Landlock + Seccomp-BPF (not Docker/VMs) → Mitigates F2 (Latency) and F5 (mcpd Backdoor)

Docker containers add 100–290ms of startup overhead per invocation — unacceptable for a terminal interface. Native kernel primitives (Landlock for filesystem isolation, Seccomp-BPF for syscall filtering) operate in-process with <1ms overhead each. They also provide tighter confinement than containers because they operate at the syscall level, below any container abstraction.

### stdio-Only mcpd → Mitigates F5 (mcpd Backdoor)

A network listener on mcpd (even localhost) is a remotely exploitable attack surface. By communicating exclusively over stdio pipes, mcpd is not reachable from any network interface. A compromised process on the same machine would need to be the immediate parent process to communicate with mcpd — this dramatically shrinks the attack surface.

### Rust for mcpd → Mitigates F5 (mcpd Backdoor)

Buffer overflows, use-after-free, and race conditions in C/C++ daemon code have been the source of countless privilege escalation exploits. Rust's ownership model eliminates these entire vulnerability classes at compile time. A Rust mcpd does not guarantee zero bugs, but it eliminates the most dangerous categories of bugs for a privileged daemon.

### Graduated Determinism (Tier 0–3) → Mitigates F4 (Approval Fatigue)

Security systems that prompt users for every action create approval fatigue — users approve without reading. The tier system routes read-only operations (Tier 0) straight through with no prompt, low-risk writes (Tier 1) through automatically with an audit log, and medium-risk operations (Tier 2) through a quick ML classifier. Only genuinely dangerous operations reach Tier 3. The result: users see Tier 3 prompts rarely enough that they read them.

### SHA-256 Manifest + Build Verification → Mitigates F6, F7, F15

Reproducible builds are a security property, not just a quality property. Pinned package versions, containerized build environments, and SHA-256 manifests ensure that what users download is what was tested and released. The mcpd startup checksum verification adds a defense-in-depth layer inside the running system.

### SFT → DPO Training Order → Mitigates F3 (Hallucination)

SFT teaches the model the NL2SH mapping. DPO then teaches it to prefer safe, minimal, reversible commands over dangerous, broad, irreversible ones — using explicit preference pairs. The combination means the model has both capability (from SFT) and judgment (from DPO). DPO on top of a random base model doesn't work well; SFT first is required.

### Opaque Reference ID Store → Mitigates F1 (Prompt Injection)

The Controller never passes raw text from the Quarantined Brain to the Privileged Brain. It stores the validated intent in a local reference store and passes only a UUID to the Privileged Brain. Even if the Quarantined Brain were compromised and produced a malicious intent object, the Privileged Brain never sees the raw text — only an abstracted, validated, schema-checked reference. This is the communication-channel equivalent of parameterized SQL queries.

---

## 6. Testing Strategy

### At Every Phase Gate

| Test Type | Tooling | What It Catches |
|---|---|---|
| Unit tests | Rust: `cargo test`, Python: `pytest` | Per-module correctness |
| Integration tests | Custom test harness | Module interaction bugs |
| Schema validation tests | `jsonschema` | Intent object and tool schema conformance |
| Latency benchmark | `hyperfine`, custom | Regression in end-to-end latency |
| Adversarial injection suite | 1,000-prompt test set | Security boundary violations |
| Fuzz testing (mcpd parameters) | `cargo fuzz` | Input validation edge cases |

### Phase-Specific Tests

| Phase | Critical Tests |
|---|---|
| Phase 1 (mcpd) | Path traversal fuzzing on `fs.*` tools; `ss -tlnp` confirms no listeners |
| Phase 2 (Controller) | 20 injection payloads → zero execution; extra-field intent → rejection |
| Phase 3 (Sandboxing) | Read `/boot/vmlinuz` from within sandbox → EACCES; blocked syscall → SIGKILL |
| Phase 4 (Fine-tuning) | FEH >90%; grammar test on 1,000 prompts → 100% valid; adversarial refusal rate ≥95% |
| Phase 5 (UX) | Tier 3 frequency <5/day; no approvals in <3 seconds |
| Phase 6 (ISO) | Boot on 3 hardware configs; AI-ready in <60s; build SHA-256 verification |
| Phase 7 (Hardening) | Full penetration test; 500-query latency benchmark; GPG signature verification |

### Continuous Integration Requirements

Every PR to `main` must pass:
1. `cargo test` — all Rust unit + integration tests
2. `pytest tests/` — all Python tests
3. Schema validation tests — intent and tool schemas
4. Path traversal fuzz test on `fs.*` (100 payloads, fast mode)
5. Adversarial injection smoke test (20 payloads)
6. Latency regression check — p95 must not increase by >10% from the stored baseline

---

## 7. Go / No-Go Gate Checklist

Use this checklist at the end of each phase before starting the next.

### Phase 0 → Phase 1
- [ ] Both GGUF models load and generate output
- [ ] MCP handshake completes over stdio
- [ ] All developers can reproduce environment in <30 minutes
- [ ] Model SHA-256 checksums recorded

### Phase 1 → Phase 2
- [ ] All mcpd tool modules pass unit tests
- [ ] MCP discovery returns full schema catalogue
- [ ] `ss -tlnp` shows zero mcpd listeners
- [ ] Path traversal fuzz returns 100% rejection
- [ ] Schema version file exists and is versioned

### Phase 2 → Phase 3
- [ ] 20/20 injection payloads → zero execution
- [ ] Controller rejects malformed/extra-field intents
- [ ] Quarantined Brain MCP tool list is empty
- [ ] Audit log records all intents, including rejected

### Phase 3 → Phase 4 (or simultaneous)
- [ ] Zero sandbox escapes in self-audit
- [ ] Landlock, Seccomp, COW each benchmark <1ms
- [ ] Total security overhead <10ms
- [ ] COW commit is atomic (crash injection verified)
- [ ] Kernel version check works correctly

### Phase 4 → Phase 5
- [ ] FEH score >90% on held-out test set
- [ ] 100% grammar-constrained outputs are valid JSON MCP calls
- [ ] Adversarial refusal rate ≥95%
- [ ] GGUF <2.5GB RAM
- [ ] SHA-256 of final GGUF recorded

### Phase 5 → Phase 6
- [ ] Tier 3 frequency <5/day in simulated usage
- [ ] No approvals in <3 seconds in usability testing
- [ ] Audit log accurate for all operations
- [ ] 10 sysadmin tasks completed by untrained users

### Phase 6 → Phase 7
- [ ] ISO boots on 3 hardware configurations
- [ ] AI-ready in <60 seconds
- [ ] Install requires zero manual steps
- [ ] build.sh SHA-256 check passes
- [ ] Full adversarial suite passes inside ISO

### Phase 7 → Release
- [ ] Zero confirmed sandbox escapes in pentest
- [ ] p95 latency <500ms (500-query benchmark)
- [ ] ISO signed with GPG
- [ ] All documentation complete
- [ ] Responsible disclosure policy published

---

*This document is authoritative for implementation sequencing. When it conflicts with the whitepaper, update this document to reflect the agreed resolution — both documents must remain in sync.*
