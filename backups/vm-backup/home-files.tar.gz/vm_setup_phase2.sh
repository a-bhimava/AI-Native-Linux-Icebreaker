#!/usr/bin/env bash
# VM setup script for Phase 2 gate verification.
# Run: bash ~/vm_setup_phase2.sh 2>&1 | tee ~/setup_phase2.log
set -euo pipefail

LOG=~/setup_phase2.log
exec > >(tee -a "$LOG") 2>&1

echo "=== $(date) START ==="
echo "Rust: $(rustc --version 2>/dev/null || echo NOT FOUND)"

# ── 1. mcpd compilation ──────────────────────────────────────────────────────
echo ""
echo "--- Step 1: compile mcpd ---"
source ~/.cargo/env 2>/dev/null || true
tar -xzf ~/mcpd-src.tar.gz -C ~ --warning=no-unknown-keyword 2>/dev/null
cd ~/src/mcpd
cargo build --release 2>&1
echo "mcpd binary: $(ls -lh ~/src/mcpd/target/release/mcpd 2>/dev/null || echo MISSING)"

# ── 2. Rebuild llama-server ──────────────────────────────────────────────────
echo ""
echo "--- Step 2: build llama-server ---"
cd ~/llama.cpp
# Try target 'llama-server', fall back to 'server'
cmake --build build --target llama-server -j"$(nproc)" 2>&1 \
  || cmake --build build --target server -j"$(nproc)" 2>&1 \
  || echo "llama-server build FAILED (both targets tried)"
# Find the binary
LLAMA_SERVER="$(find ~/llama.cpp/build -type f -name 'llama-server' -o -type f -name 'server' 2>/dev/null \
  | grep -v '\.so\|tools/server\|CMake\|ui' | head -1)"
echo "llama-server: ${LLAMA_SERVER:-NOT FOUND}"

# ── 3. Download QB model ─────────────────────────────────────────────────────
echo ""
echo "--- Step 3: download QB model ---"
QB_MODEL=~/models/qwen2.5-1.5b-instruct-q4_k_m.gguf
if [ -f "$QB_MODEL" ]; then
  echo "QB model already present: $(ls -lh "$QB_MODEL" | awk '{print $5}')"
else
  echo "Downloading qwen2.5-1.5b-instruct-q4_k_m.gguf (~986MB)..."
  wget -q --show-progress \
    -O "$QB_MODEL" \
    "https://huggingface.co/lmstudio-community/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_K_M.gguf" \
    && echo "QB model download complete: $(ls -lh "$QB_MODEL" | awk '{print $5}')" \
    || echo "QB model download FAILED"
fi

echo ""
echo "=== $(date) SETUP COMPLETE ==="
echo ""
echo "--- Summary ---"
ls ~/src/mcpd/target/release/mcpd 2>/dev/null && echo "mcpd: READY" || echo "mcpd: MISSING"
find ~/llama.cpp/build -type f \( -name 'llama-server' -o -name 'server' \) 2>/dev/null \
  | grep -v '\.so\|tools/server\|CMake\|ui' | head -1 | xargs -I{} echo "llama-server: {} READY" \
  || echo "llama-server: MISSING"
ls "$QB_MODEL" 2>/dev/null && echo "QB model: READY" || echo "QB model: MISSING"
